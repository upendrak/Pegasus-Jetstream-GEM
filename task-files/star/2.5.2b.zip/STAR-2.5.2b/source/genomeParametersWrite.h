#ifndef CODE_genomeParametersWrite
#define CODE_genomeParametersWrite
#include "Parameters.h"

void genomeParametersWrite(string fileName, Parameters* P, string errorOut);

#endif